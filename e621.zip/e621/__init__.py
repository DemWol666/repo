from .api import E621, E926

__author__ = "PatriotRossii"
__version__ = "0.0.7"
__email__ = "patriotrosii2019@mail.ru"
